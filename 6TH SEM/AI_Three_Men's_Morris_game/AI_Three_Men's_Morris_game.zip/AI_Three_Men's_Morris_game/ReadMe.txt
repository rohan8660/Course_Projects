To run this game.

1.Install Python 3.X
2.Install easyAI package